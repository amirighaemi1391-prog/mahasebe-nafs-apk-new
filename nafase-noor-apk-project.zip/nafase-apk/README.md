# محاسبه نفس — Android APK

این پروژه نسخه HTML موجود را بدون نیاز به Netlify داخل WebView اندروید اجرا می‌کند.

## ساخت APK
1. پروژه را با Android Studio باز کنید.
2. صبر کنید Gradle Sync تمام شود.
3. از منوی Build گزینه Build APK(s) را بزنید.
4. APK در app/build/outputs/apk/debug/ قرار می‌گیرد.

نام برنامه: محاسبه نفس
Package: com.amir.nasafeno
Version: 1.0
